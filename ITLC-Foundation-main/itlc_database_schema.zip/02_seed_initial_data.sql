-- ============================================================================
-- ITLC FOUNDATION - INITIAL SEED DATA (CORE SYSTEM TABLES)
-- ============================================================================
USE `itlc_foundation`;

-- 1. Master SuperAdmin Account
INSERT INTO `admins` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`)
VALUES
(1, 'admin', 'info@itlcfoundation.com', '$2b$10$e8c1Q0Fz9k2...admin123', 'super_admin', 1)
ON DUPLICATE KEY UPDATE `email` = VALUES(`email`), `role` = VALUES(`role`);

-- 2. Organization Site Settings
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `group_name`) VALUES
('site_name', 'ITLC Foundation', 'general'),
('site_tagline', 'Empowering Communities Through Learning & Care', 'general'),
('contact_email', 'info@itlcfoundation.com', 'contact'),
('contact_phone', '+91 93361 88402', 'contact'),
('helpline_phone', '+91 94151 05000', 'contact'),
('office_address', 'G1/0049, Olive Wood Villa, Golf City, Sector D, Pocket 1, Lucknow, UP - 226030', 'contact'),
('tax_exemption_80g', '50% Tax Exemption under Section 80G of Income Tax Act 1961', 'donation'),
('currency', 'INR', 'donation'),
('smtp_host', 'smtp.hostinger.com', 'email'),
('smtp_port', '465', 'email'),
('smtp_user', 'donation@itlcfoundation.com', 'email')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

-- 3. Core Focus Areas / Services
INSERT INTO `services` (`service_key`, `title`, `slug`, `short_description`, `display_order`, `is_active`) VALUES
('animal-welfare', 'Animal Welfare & Rescue', 'animal-welfare', 'Rescue, medical treatment, sterilization, and feeding of stray animals across Lucknow & UP.', 1, 1),
('paryavaran-sanrakshan', 'Environment Protection & Plantation', 'paryavaran-sanrakshan', 'Large-scale afforestation, native tree plantation, and anti-plastic campaigns in UP.', 2, 1),
('women-empowerment', 'Women Empowerment & Skill Center', 'women-empowerment', 'Vocational tailoring, computer literacy, and self-help micro-enterprise training for rural women.', 3, 1),
('education', 'Education Support & Digital Learning', 'education', 'Free digital classrooms, school kits, and scholarship mentoring for underprivileged children.', 4, 1),
('clean-water', 'Clean Water & Rural Sanitation', 'clean-water', 'Installing community water filtration plants and hygienic sanitation blocks in remote villages.', 5, 1),
('social-welfare', 'Community Welfare & Relief Drives', 'social-welfare', 'Disaster relief, winter warm blanket distribution, and nutritional food drives across UP.', 6, 1)
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);

-- 4. Initial Ground Projects
INSERT INTO `projects` (`id`, `slug`, `title`, `category`, `short_description`, `goal_amount`, `raised_amount`, `status`, `published`) VALUES
(1, 'green-lucknow-10k-trees', 'Mission 10,000 Green Trees for Lucknow', 'Environment', 'Planting 10,000 indigenous neem, peepal, and banyan trees across Gomti riverbed and schools.', 500000.00, 320000.00, 'Ongoing', 1),
(2, 'stray-animal-mobile-ambulance', '24x7 Animal Rescue & Mobile Clinic', 'Animal Welfare', 'Dedicated mobile ambulance van equipped with medical first-aid for emergency animal rescue in Lucknow.', 750000.00, 485000.00, 'Ongoing', 1),
(3, 'rural-digital-classrooms', 'Shiksha Jyoti Rural Classrooms', 'Education', 'Equipping 15 rural primary schools in Barabanki and Lucknow with solar power and digital tablet labs.', 600000.00, 410000.00, 'Ongoing', 1)
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);