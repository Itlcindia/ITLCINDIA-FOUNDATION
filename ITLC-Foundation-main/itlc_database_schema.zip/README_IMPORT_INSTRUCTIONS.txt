================================================================================
ITLC FOUNDATION - DATABASE SCHEMA & IMPORT GUIDE
================================================================================

Package Contents:
-----------------
1. 01_db_schema.sql         -> Complete MySQL Database Schema (24 Production Tables,
                               Foreign Keys, Indexes, Triggers, and Constraints)
2. 02_seed_initial_data.sql -> Initial Seed Data (SuperAdmin info@itlcfoundation.com,
                               6 Focus Areas, Live Projects, and Site Settings)
3. json_data/               -> Complete Live JSON Database Files:
                               - admin_accounts.json
                               - cms_data.json
                               - blogs.json
                               - projects.json
                               - donations.json
                               - contact_inquiries.json
                               - volunteers.json
                               - team_members.json

--------------------------------------------------------------------------------
HOW TO IMPORT INTO HOSTINGER CLOUD / PHPMYADMIN:
--------------------------------------------------------------------------------
Step 1: Open Hostinger hPanel (hpanel.hostinger.com)
Step 2: Go to "Databases" -> "MySQL Databases"
Step 3: Create a new database:
        - Database Name: itlc_foundation (or your desired name)
        - Username: [your_db_username]
        - Password: [your_db_password]
Step 4: Click "Enter phpMyAdmin" next to your newly created database.
Step 5: Click on the "Import" tab at the top.
Step 6: Click "Choose File" -> Select "01_db_schema.sql" -> Click "Import" at the bottom.
Step 7: Click "Choose File" -> Select "02_seed_initial_data.sql" -> Click "Import".
Step 8: Done! All 24 tables and initial records are live.

--------------------------------------------------------------------------------
ENVIRONMENT VARIABLES (.env) CONFIGURATION:
--------------------------------------------------------------------------------
Add these keys to your .env file on the server:

DB_HOST=localhost
DB_USER=your_db_username
DB_PASSWORD=your_db_password
DB_NAME=itlc_foundation
DB_PORT=3306

SuperAdmin Login Credentials:
Email: info@itlcfoundation.com
Default Password: admin123
================================================================================