-- Create Database if not exists
CREATE DATABASE IF NOT EXISTS `itlc_foundation` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `itlc_foundation`;

-- Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `is_subadmin` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admins` (`username`, `password_hash`, `email`, `is_subadmin`) VALUES 
('admin', '$2y$10$Rr.hVYjY8oHglnVjjJ9hLep4vkYlcgVJ757LdetAtuhf1NxciUC5m', 'info@itlcfoundation.org', 0)
ON DUPLICATE KEY UPDATE `password_hash` = VALUES(`password_hash`);

-- Navbar Links Table
CREATE TABLE IF NOT EXISTS `navbar_links` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `label` VARCHAR(100) NOT NULL,
  `href` VARCHAR(255) NOT NULL,
  `parent_id` INT DEFAULT NULL,
  `sort_order` INT DEFAULT 0,
  `page_title` VARCHAR(255) DEFAULT '',
  `page_content` TEXT DEFAULT NULL,
  `page_image_url` VARCHAR(255) DEFAULT '',
  `page_image_hint` VARCHAR(255) DEFAULT '',
  FOREIGN KEY (`parent_id`) REFERENCES `navbar_links`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hero Content Table
CREATE TABLE IF NOT EXISTS `hero_content` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `heading` VARCHAR(255) NOT NULL,
  `paragraph` TEXT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Key Projects Table
CREATE TABLE IF NOT EXISTS `key_projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `image_hint` VARCHAR(255) DEFAULT '',
  `progress` INT DEFAULT 0,
  `status` VARCHAR(50) DEFAULT 'Ongoing',
  `is_main` TINYINT(1) DEFAULT 0,
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FAQ Table
CREATE TABLE IF NOT EXISTS `faq_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question` TEXT NOT NULL,
  `answer` TEXT NOT NULL,
  `page` VARCHAR(50) DEFAULT 'home', -- 'home' or 'donate'
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Moments of Impact (Gallery Preview)
CREATE TABLE IF NOT EXISTS `moments_of_impact` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `image_url` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `category` VARCHAR(50) DEFAULT 'Events',
  `image_hint` VARCHAR(255) DEFAULT '',
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Blogs Table
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `excerpt` TEXT NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `image_hint` VARCHAR(255) DEFAULT '',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Footer Table
CREATE TABLE IF NOT EXISTS `footer_content` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cta_heading` VARCHAR(255) NOT NULL,
  `cta_subheading` TEXT NOT NULL,
  `about_text` TEXT NOT NULL,
  `facebook_url` VARCHAR(255) DEFAULT '#',
  `twitter_url` VARCHAR(255) DEFAULT '#',
  `instagram_url` VARCHAR(255) DEFAULT '#',
  `linkedin_url` VARCHAR(255) DEFAULT '#',
  `contact_email` VARCHAR(100) NOT NULL,
  `contact_address` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Donations Table
CREATE TABLE IF NOT EXISTS `donations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `donor_name` VARCHAR(100) NOT NULL,
  `donor_email` VARCHAR(100) NOT NULL,
  `donor_phone` VARCHAR(20) DEFAULT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `type` VARCHAR(20) NOT NULL, -- 'one-time' or 'monthly'
  `status` VARCHAR(20) DEFAULT 'pending', -- 'pending', 'success', 'failed'
  `razorpay_order_id` VARCHAR(100) DEFAULT NULL,
  `razorpay_payment_id` VARCHAR(100) DEFAULT NULL,
  `razorpay_signature` VARCHAR(255) DEFAULT NULL,
  `razorpay_subscription_id` VARCHAR(100) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Subscriptions Table (Track active/cancelled monthly plans)
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `donor_name` VARCHAR(100) NOT NULL,
  `donor_email` VARCHAR(100) NOT NULL,
  `donor_phone` VARCHAR(20) DEFAULT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'active', -- 'active', 'cancelled'
  `razorpay_subscription_id` VARCHAR(100) NOT NULL UNIQUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Seed Navbar Links
INSERT INTO `navbar_links` (`id`, `label`, `href`, `parent_id`, `sort_order`, `page_title`, `page_content`, `page_image_url`) VALUES
(1, 'Home', '/', NULL, 0, 'ITLC Foundation - Home Portal', 'Welcome to the administration panel of ITLC Foundation. Select any menu page or content section to begin updating the live website.', '/pro/ab.png'),
(2, 'About', '/about', NULL, 1, 'ITLC Foundation - Reclaiming Nature, Empowering Lives', 'Founded with a vision to create a sustainable and equitable world, ITLC Foundation has been at the forefront of social and environmental change in Lucknow. Our approach addresses critical needs in environmental conservation, animal welfare, and community development.', '/pro/ab.png'),
(3, 'Projects', '/projects', NULL, 2, 'Key Projects', 'Check active campaigns and direct support drives in Lucknow.', '/pro/t.png'),
(4, 'Services', '/services', NULL, 3, 'Our Core Services', 'Supporting Lucknow and Uttar Pradesh communities through multi-faceted social and environmental programs.', '/pro/ab.png'),
(5, 'Gallery', '/gallery', NULL, 4, 'ITLC Foundation - Public Gallery', 'Glimpses of our welfare, plantation, and animal care work in Lucknow, capturing the heart of our mission in action.', '/gal/b.png'),
(6, 'Insides', '/blog', NULL, 5, 'ITLC Insides', 'Follow latest articles and progress logs from the ground.', '/pro/1.png'),
(7, 'Contact', '/contact', NULL, 6, 'Get in Touch with ITLC Foundation', 'Have questions, suggestions, or want to partner with us? Reach out to our Lucknow office today. Together, we can make a difference and uplift communities.', '/pro/c.png');

INSERT INTO `navbar_links` (`label`, `href`, `parent_id`, `sort_order`, `page_title`, `page_content`, `page_image_url`) VALUES
('All Services', '/services', 4, 0, 'All NGO Services', 'All environmental and community development programs in Lucknow.', '/pro/ab.png'),
('Social Welfare', '/social-welfare', 4, 1, 'A Leading Social Welfare NGO in Lucknow', 'Supporting health, education, women empowerment, and the elderly through our dedicated welfare programs in Uttar Pradesh. We work on child nutrition, women skill development, and health checkup camps.', '/pro/ab.png'),
('Paryavaran Sanrakshan', '/paryavaran-sanrakshan', 4, 2, 'Environmental Protection & Afforestation in Lucknow', 'ITLC Foundation leads tree plantation and environmental protection campaigns to combat deforestation and build a sustainable future in Uttar Pradesh. We conduct seed ball distributions, afforestation drives, and waste management campaigns.', '/pro/t.png'),
('Animal Welfare', '/animal-welfare', 4, 3, 'Dedicated Animal Welfare & Care NGO in Lucknow', 'Protecting, feeding, and providing medical aid to stray animals and birds across Lucknow. We believe every life deserves care and compassion, running stray rescue initiatives and nesting installations.', '/pro/ab.png');

-- Seed Hero Content
INSERT INTO `hero_content` (`heading`, `paragraph`, `image_url`) VALUES
('Empowering Change in Lucknow,\nOne Act at a Time.', 'Join ITLC Foundation, a leading NGO in Lucknow, on our mission to create lasting impact across Uttar Pradesh. Your support empowers us to serve humanity, protect nature, and save lives. Become a part of the change today.', '/pro/3.png');

-- Seed Key Projects
INSERT INTO `key_projects` (`title`, `category`, `description`, `image_url`, `image_hint`, `progress`, `status`, `is_main`, `sort_order`) VALUES
('Massive Afforestation 2024', 'Environment', 'Join our environmental NGO in Lucknow in our ambitious goal to plant 100,000 trees by 2024, combating deforestation in Uttar Pradesh and restoring vital ecosystems.', '/pro/t.png', 'lush forest trees', 75, 'Ongoing', 1, 0),
('Clean Water Initiative', 'Health', 'As a leading health awareness NGO in Lucknow, we provide access to clean and safe drinking water for remote villages through new wells and filtration systems.', '/pro/2.png', 'clean water tap', 0, 'Featured Project', 0, 1),
('Digital Literacy for Kids', 'Education', 'Our education support program in Lucknow equips children in underprivileged areas with essential digital skills for a brighter future.', '/pro/1.png', 'child using laptop', 0, 'New', 0, 2);

-- Seed FAQs for Home Page
INSERT INTO `faq_items` (`question`, `answer`, `page`, `sort_order`) VALUES
('What is ITLC Foundation?', 'ITLC Foundation is a leading non-profit NGO in Lucknow, Uttar Pradesh, dedicated to impactful social welfare, environmental protection, and animal care. We run various on-ground initiatives to support communities and create a sustainable future for all.', 'home', 0),
('How can I donate to your NGO in Lucknow?', 'You can make a secure donation to our NGO through our website by clicking the \"Donate Now\" button. We accept various payment methods, and all donations are eligible for 80G tax benefits. Your contribution directly supports our projects in Uttar Pradesh.', 'home', 1),
('Can I volunteer for your foundation in Lucknow?', 'Absolutely! We are always looking for passionate volunteers to join our NGO in Lucknow. Please visit our \"Contact\" page and fill out the form to get involved. We have diverse opportunities in our education, environmental, and welfare projects.', 'home', 2),
('How is my donation used by your organization?', 'We are a transparent NGO. 100% of your donation is used for on-ground activities in Lucknow and across UP. You can view our detailed financial and impact reports on our \"Transparency\" page to see how your contribution makes a difference.', 'home', 3);

-- Seed FAQs for Donate Page
INSERT INTO `faq_items` (`question`, `answer`, `page`, `sort_order`) VALUES
('Is my donation to your NGO secure?', 'Yes, your donation is 100% secure. We use industry-standard encrypted payment gateways to ensure your information is safe. You can donate with confidence to our NGO in Lucknow.', 'donate', 0),
('Can I get a tax receipt for my donation?', 'Yes, all donations made to ITLC Foundation, a registered NGO, are eligible for tax exemption under section 80G of the Income Tax Act, India. You will receive the 80G receipt via email.', 'donate', 1),
('How is my donation used by your NGO?', 'We believe in 100% transparency. 90% of your donation goes directly to our social welfare, education, and environmental projects in Lucknow. The remaining 10% is used for administrative and logistical expenses to ensure smooth operations.', 'donate', 2),
('Can I set up a recurring monthly donation?', 'Yes, you can become a regular supporter of our NGO. Simply choose the ''Monthly'' option on the donation form to set up a recurring donation and provide continuous support to our causes in Uttar Pradesh.', 'donate', 3);

-- Seed Moments of Impact (Gallery)
INSERT INTO `moments_of_impact` (`id`, `image_url`, `description`, `category`, `image_hint`, `sort_order`) VALUES
(1, '/gal/b.png', 'Food distribution event to needy families.', 'Events', 'charity food', 0),
(2, '/gal/e.png', 'Volunteers distributing blankets in winter.', 'Events', 'winter charity', 1),
(3, 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxjb21tdW5pdHklMjBldmVudHxlbnwwfHx8fDA%3D&ixlib=rb-4.1.0&q=80&w=1080', 'A community gathering for an awareness program.', 'Events', 'community event', 2),
(4, 'https://images.unsplash.com/photo-1584062134595-dacde0a2336d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxjaGlsZCUyMHBsYW50aW5nfGVufDB8fHx8MTc3MTgzODQwNnww&ixlib=rb-4.1.0&q=80&w=1080', 'A young child watering a newly planted sapling.', 'Plantation', 'child planting', 3),
(5, '/gal/c.png', 'A dense area of freshly planted trees.', 'Plantation', 'tree plantation', 4),
(6, 'https://images.unsplash.com/photo-1758599668429-121d54188b9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHx2b2x1bnRlZXJzJTIwZ3JvdXB8ZW58MHx8fHwxNzc1NTg5NTAwfDA%3D&ixlib=rb-4.1.0&q=80&w=1080', 'Volunteers posing after a successful plantation drive.', 'Plantation', 'volunteers group', 5),
(7, '/gal/a.png', 'A volunteer handing a school kit to a child.', 'Welfare', 'education children', 6),
(8, '/gal/g.png', 'Bags of ration ready for distribution.', 'Welfare', 'food aid', 7),
(9, 'https://images.unsplash.com/photo-1758612898715-a354d0e62a03?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxlbGRlcmx5JTIwaGVscHxlbnwwfHx8fDA%3D&ixlib=rb-4.1.0&q=80&w=1080', 'An elderly person receiving aid.', 'Welfare', 'elderly help', 8),
(10, '/gal/d.png', 'A volunteer feeding a stray dog.', 'Animal Care', 'feeding dog', 9),
(11, '/gal/f.png', 'A rescued kitten being cared for.', 'Animal Care', 'rescue kitten', 10),
(12, 'https://images.unsplash.com/photo-1626511140389-f1fa321c4618?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw8fHxhbmltYWwlMjBhbWJ1bGFuY2V8ZW58MHx8fHww&ixlib=rb-4.1.0&q=80&w=1080', 'A mobile medical van for animal treatment.', 'Animal Care', 'animal ambulance', 11);

-- Seed Blogs
INSERT INTO `blogs` (`title`, `excerpt`, `category`, `image_url`, `image_hint`) VALUES
('Why Tree Plantation Matters for a Greener Lucknow', 'As a leading environmental NGO in Lucknow, we explore the critical role of trees in our ecosystem and how our monthly drives are making a tangible difference in Uttar Pradesh.', 'Environment', 'https://images.unsplash.com/photo-1638432546372-7c6adf2ec9f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHx0cmVlJTIwc2FwbGluZ3xlbnwwfHx8fDE3NzE4Mzg0MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080', 'tree sapling'),
('A Day in the Life: Our Animal Rescue Team in Lucknow', 'A heartwarming story from our animal welfare team about the challenges and rewards of caring for city strays. Discover the impact of our animal welfare NGO in Lucknow.', 'Animal Welfare', '/gal/f.png', 'stray dog'),
('The Ripple Effect: Community Welfare in Uttar Pradesh', 'Learn how supporting one family can uplift an entire community. A story from our food distribution drives, showcasing our commitment as a social welfare organization in UP.', 'Social Welfare', '/gal/g.png', 'community people');

-- Seed Footer Content
INSERT INTO `footer_content` (`cta_heading`, `cta_subheading`, `about_text`, `facebook_url`, `twitter_url`, `instagram_url`, `linkedin_url`, `contact_email`, `contact_address`) VALUES
('Together We Can Create a Greener Tomorrow 🌍', 'Your support drives our mission to protect nature, serve humanity, and save lives.', 'Empowering communities through environmental protection, animal welfare, and high-impact social welfare programs. Dedicated to making Lucknow and Uttar Pradesh thrive.', '#', '#', '#', '#', 'info@itlcfoundation.org', 'G1/0049,Olive Wood Villa, Golf City, Lucknow, Uttar Pradesh – 226030');

-- Donate Page Content Table
CREATE TABLE IF NOT EXISTS `donate_page_content` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `main_heading` VARCHAR(255) NOT NULL,
  `main_subheading` TEXT NOT NULL,
  `side_image_url` VARCHAR(255) NOT NULL,
  `qr_title` VARCHAR(255) NOT NULL,
  `qr_description` VARCHAR(255) NOT NULL,
  `qr_image_url` VARCHAR(255) NOT NULL,
  `transparency_text` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `donate_page_content` (`id`, `main_heading`, `main_subheading`, `side_image_url`, `qr_title`, `qr_description`, `qr_image_url`, `transparency_text`) VALUES
(1, 'Make a Difference in Lucknow Today', 'Your support is crucial for our social welfare mission in Uttar Pradesh.', '/pro/c.png', 'Scan to Support Our NGO', 'Quickly donate to our Lucknow projects via any UPI App', '/qr.png', 'Hum har donation ka proper utilization record maintain karte hain aur donors ko updates provide karte hain. Your trust is our biggest asset. As a top NGO in Lucknow, transparency is our priority.');
